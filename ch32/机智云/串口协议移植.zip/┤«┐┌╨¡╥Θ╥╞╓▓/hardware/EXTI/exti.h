#ifndef  _EXTI_H
#define  _EXTI_H

#include "stm32f10x.h"

void EXTIX_Init(void);

#endif

