#ifndef _DELAY_H_
#define _DELAY_H_







void Delay_Init(void);

void DelayUs(unsigned short us);

void DelayXms(unsigned short ms);

void DelayMs(unsigned short ms);

#endif
